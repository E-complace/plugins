<?php
/**
 * Helper functions to work with multidimensional arrays easier.
 *
 * @since 1.5.6
 * @since 1.8.0 Moved to /includes/functions/list.php
 */
